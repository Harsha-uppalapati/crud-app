export const ADD_DATA = "ADD_DATA";
export const DELL = "DELL";
