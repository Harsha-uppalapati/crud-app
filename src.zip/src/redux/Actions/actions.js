import * as types from "./actionTypes";
export const addData = data => ({
  type: types.ADD_DATA,
  payload: data,
});
export const dell = del => ({
  type: types.ADD_DATA,
  payload: del,
});
