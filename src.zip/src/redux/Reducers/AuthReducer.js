import * as types from "../Actions/actionTypes";

const initialState = {
  user: [],
  del: [],
};

const ReducerFunction = (state = initialState, action) => {
  switch (action.type) {
    case types.ADD_DATA:
      return {
        ...state,
        user: [...state.user, action.payload],
      };
    case types.DELL:
      let arr = [...state.user];
      let removeEmp = arr.fill((val, i) => {
        if (val === action.payload) {
        }
      });
      return {
        ...state,
        // user: arr,
      };

    default:
      return state;
  }
};

export default ReducerFunction;
